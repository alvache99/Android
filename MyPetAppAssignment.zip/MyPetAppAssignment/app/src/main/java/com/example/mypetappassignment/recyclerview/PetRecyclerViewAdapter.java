package com.example.mypetappassignment.recyclerview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mypetappassignment.R;
import com.example.mypetappassignment.entities.Pet;

import java.util.List;

public class PetRecyclerViewAdapter extends RecyclerView.Adapter<PetViewHolder> {
    private List<Pet> pets;
    private Context context;

    public PetRecyclerViewAdapter(List<Pet> pets, Context context){
        this.pets = pets;
        this.context = context;

    }

    @NonNull
    @Override
    public PetViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());

        View petViewCard = inflater.inflate(R.layout.individual_pet,parent,false);
        PetViewHolder petviewholder = new PetViewHolder(petViewCard);

        return petviewholder;
    }

    @Override
    public void onBindViewHolder(@NonNull PetViewHolder holder, int position) {
        Pet pet = pets.get(position);
        holder.updatePet(pet);
    }

    @Override
    public int getItemCount() {
        return pets.size();
    }


    public List<Pet> getPets() {
        return pets;
    }
}
