package com.example.mypetappassignment.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.example.mypetappassignment.entities.Pet;

import java.util.ArrayList;
import java.util.List;

public class PetDbHelper extends SQLiteOpenHelper {
    private static final String TAG = PetDbHelper.class.getName();

    private static PetDbHelper mInstance = null;
    private Context context;

    //Initialize db essentials
    private static final String DATABASE_NAME = "pet.db";
    private static final Integer DATABASE_VERSION = 1;
    private static final String TABLE_NAME = "petlist";

    //Initializing constants for column name
    private static final String COL_ID = "ID";
    private static final String COL_NAME = "NAME";
    private static final String COL_USERNAME = "USERNAME";
    private static final String COL_AGE = "AGE";
    private static final String COL_IMAGE = "IMAGE";
    private static final String COL_BREED = "BREED";
    private static final String COL_TYPE = "TYPE";

    private static final String CREATE_TABLE_ST = "CREATE TABLE " + TABLE_NAME + "(" + COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COL_NAME + " TEXT, " +
            COL_USERNAME + " TEXT, " +
            COL_AGE + " INTEGER, " +
            COL_IMAGE + " TEXT, " +
            COL_BREED + " TEXT, " +
            COL_TYPE + "  TEXT )";

    private static final String DROP_TABLE_ST = "DROP TABLE IF EXISTS " + TABLE_NAME;
    private static final String GET_ALL_ST= "SELECT * FROM "+TABLE_NAME;

    //Instantiating the database and making sure only once so that it wont instantiate multiple dbs.
    public static synchronized PetDbHelper getInstance(Context ctx) {
        if (mInstance == null) {
            mInstance = new PetDbHelper(ctx.getApplicationContext());
        }
        return mInstance;
    }


    private PetDbHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }


    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(CREATE_TABLE_ST);
    }


    //For new version/Upgrading db. Int i , int i1 represents previous and latest versions of the db
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL(DROP_TABLE_ST);
        onCreate(sqLiteDatabase);
    }

    public Long insert(String name, String username, String type, String breed, Long age,String image) {
        //create an instance of SQLITE database
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_NAME, name);
        contentValues.put(COL_AGE, age);
        contentValues.put(COL_TYPE, type);
        contentValues.put(COL_USERNAME, username);
        contentValues.put(COL_IMAGE,image);
        contentValues.put(COL_BREED, breed);

        Long result = db.insert(TABLE_NAME, null, contentValues);
        db.close();
        //if result is -1  insert was not performed due to an error, otherwise will have the row ID of the newly inserted row
        return result;
    }

    public boolean update(Long id,String name, String username, String type, String breed, Long age,String image) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_ID, id);
        contentValues.put(COL_NAME, name);
        contentValues.put(COL_AGE, age);
        contentValues.put(COL_TYPE, type);
        contentValues.put(COL_USERNAME, username);
        contentValues.put(COL_IMAGE,image);

        int numOfRowsUpdated = db.update(TABLE_NAME, contentValues, "ID = ?", new String[]{id.toString()});
        db.close();
        return numOfRowsUpdated == 1;
    }

    public boolean delete(Long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        //delete return the # of rows affected by the query
        int numOfRowsDeleted = db.delete(TABLE_NAME, "ID = ?", new String[]{id.toString()});
        db.close();
        return numOfRowsDeleted == 1;//if your query is going to delete more than 1 record (this is not the case) then the condition will be numOfRowsDeleted > 0
    }
    private Cursor getAll() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery(GET_ALL_ST, null);
    }
    public List<Pet> getPets() {
        List<Pet> pets = new ArrayList<>();
        Cursor cursor = getAll();

        if(cursor.getCount() > 0) {
           Pet pet;
            while (cursor.moveToNext()) {
                Long id = cursor.getLong(0);
                String name = cursor.getString(1);
                String username = cursor.getString(2);
                Long age = cursor.getLong(3);
                String imageFileName = cursor.getString(4);
                String breed = cursor.getString(5);
                String type = cursor.getString(6);

               pet = new Pet(type, name,age,  breed,  username,  id,imageFileName);
                pets.add(pet);
            }
        }
        cursor.close();
        return pets;
    }








}
