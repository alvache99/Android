package com.example.mypetappassignment.entities;

import java.io.Serializable;

public class Pet implements Serializable {
    private String name;
    private Long age;
    private String type;
    private String breed;
    private String username;
    private Long ID;
    private String image;
    public static final String PET_KEY = "pet_key";

    public Pet(String type,String name,Long age, String breed, String username, Long ID,String image) {
        this.type = type;
        this.name = name;
        this.age = age;
        this.breed = breed;
        this.username = username;
        this.ID = ID;
        this.image = image;
    }

    public Pet(){};
    public String getBreed() {
        return breed;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getAge() {
        return age;
    }

    public void setAge(Long age) {
        this.age = age;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Long getID() {
        return ID;
    }

    public void setID(Long ID) {
        this.ID = ID;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
