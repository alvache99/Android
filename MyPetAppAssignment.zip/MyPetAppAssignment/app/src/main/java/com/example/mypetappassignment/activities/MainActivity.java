package com.example.mypetappassignment.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.mypetappassignment.R;

public class MainActivity extends AppCompatActivity {
Button essentialButton;
Button loginInitButton;
Button aboutInitButton;
Button singupInitButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        essentialButton = findViewById(R.id.EssentialButton);
        loginInitButton = findViewById(R.id.loginButton);
        aboutInitButton = findViewById(R.id.aboutButton);
        singupInitButton = findViewById(R.id.signupBtnMain);

        essentialButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //state our itention. Set a referencing variable for your next activity
                Intent switchToEssentialActivity = new Intent(v.getContext(), EssentialServActivity.class);
               //When button clicks it brings to login page
                startActivity(switchToEssentialActivity);
            }
        });

        loginInitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent switchToLoginAcitivity = new Intent(v.getContext(),PetlistActivity.class);
                startActivity(switchToLoginAcitivity);
            }
        });

        singupInitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent switchToSignupActivity = new Intent(v.getContext(),SignupActivity.class);
                startActivity(switchToSignupActivity);
            }
        });




    }
}
