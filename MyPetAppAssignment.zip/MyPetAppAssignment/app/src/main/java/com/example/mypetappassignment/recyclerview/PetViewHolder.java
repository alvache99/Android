package com.example.mypetappassignment.recyclerview;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mypetappassignment.R;
import com.example.mypetappassignment.entities.Pet;


public class PetViewHolder extends RecyclerView.ViewHolder {

    public ImageView petPic = null;
    public final TextView nameLabel = null;
    public  TextView name = null;
    public final TextView ageLabel = null;
    public  TextView age = null;
    public final TextView typeLabel = null;
    public  TextView type = null;
    public final TextView breedLabel = null;
    public  TextView breed = null;
    public final Button viewButton = null;
    public final Button deleteButton = null;



    public PetViewHolder(@NonNull View itemView) {
        super(itemView);
        petPic = itemView.findViewById(R.id.petImageView);
        name = itemView.findViewById(R.id.nameText);
        age = itemView.findViewById(R.id.ageText);
        type = itemView.findViewById(R.id.typeText);

    }

    public void updatePet(Pet pet){
        View rootView = petPic.getRootView();
        name.setText(pet.getName());
        age.setText(pet.getAge().toString());
        type.setText(pet.getType());
        breed.setText(pet.getBreed());
        int imageResID = rootView.getResources().getIdentifier(pet.getImage(),"drawable",rootView.getContext().getPackageName());
        petPic.setImageResource(imageResID);

    }


}
