package com.example.mypetappassignment.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.mypetappassignment.R;

public class SignupActivity extends AppCompatActivity {
Button backBtnSignup;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        backBtnSignup = findViewById(R.id.backBtnSignup);


        backBtnSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goingBackFrmSignup = new Intent();
                setResult(RESULT_OK,goingBackFrmSignup);
                finish();
            }
        });

    }
}
