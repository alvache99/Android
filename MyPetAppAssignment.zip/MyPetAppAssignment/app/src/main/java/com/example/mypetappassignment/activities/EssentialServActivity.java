package com.example.mypetappassignment.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.mypetappassignment.R;

public class EssentialServActivity extends AppCompatActivity {
Button btn1;
Button btn2;
Button btn3;
Button btn4;
Button btn5;
Button backButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_essential_serv);
        btn1 = findViewById(R.id.btnES1);
        btn2 = findViewById(R.id.btnES2);
        btn3 = findViewById(R.id.btnES3);
        btn4 = findViewById(R.id.btnES4);
        btn5 = findViewById(R.id.btnES5);
        backButton = findViewById(R.id.backBtn);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=Nearest+vet+to+me&rlz=1C1CHBF_en-GBAU821AU821&oq=Nearest+vet+to+me&aqs=chrome..69i57j0l7.2158j0j7&sourceid=chrome&ie=UTF-8"));
                startActivity(browserIntent);
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/search?rlz=1C1CHBF_en-GBAU821AU821&sxsrf=ALeKk02EjGVRuE95zR9WjfHL8BK-U6IAuA%3A1591000642076&ei=Qr7UXvXWA5GamgfBjJDACA&q=nearest+pet+food+store+to+me&oq=nearest+pet+food+store+to+me&gs_lcp=CgZwc3ktYWIQAzICCAAyCAgAEBYQChAeMgYIABAWEB4yBggAEBYQHjIGCAAQFhAeOgQIABBHUNsFWIMKYNwKaABwAXgAgAH8AogBlwiSAQUyLTEuMpgBAKABAaoBB2d3cy13aXo&sclient=psy-ab&ved=0ahUKEwj1_-2gm-DpAhURjeYKHUEGBIgQ4dUDCAw&uact=5"));
                startActivity(browserIntent);
            }
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/search?rlz=1C1CHBF_en-GBAU821AU821&sxsrf=ALeKk02yGLdoZYrIvldr0XUPM1L_EbMh2g%3A1591000644758&ei=RL7UXoL0LZHBz7sPtvi3mAY&q=nearest+pet+grooming++to+me&oq=nearest+pet+grooming++to+me&gs_lcp=CgZwc3ktYWIQAzICCAA6BAgAEEc6CAgAEAcQChAeOgYIABAHEB46CAgAEAgQBxAeULr0AljRhQNg8o0DaABwAXgAgAG8B4gB8B6SAQkwLjQuMy42LTOYAQCgAQGqAQdnd3Mtd2l6&sclient=psy-ab&ved=0ahUKEwiCppKim-DpAhWR4HMBHTb8DWMQ4dUDCAw&uact=5"));
                startActivity(browserIntent);
            }
        });

        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/search?rlz=1C1CHBF_en-GBAU821AU821&sxsrf=ALeKk03kVz6aVzt2aGjrGFPQkL4a2QQ7cg%3A1591000776479&ei=yL7UXsvoHIzYz7sP6qWJqAg&q=nearest+pet+care+center&oq=nearest+pet+care&gs_lcp=CgZwc3ktYWIQAxgCMgQIIxAnMgIIADICCAAyBggAEBYQHjoECAAQRzoFCAAQkQI6BAgAEEM6BAgAEAo6BwgAEBQQhwJQzBBYvBdgsyhoAHABeACAAb4BiAHFBpIBAzAuNZgBAKABAaoBB2d3cy13aXo&sclient=psy-ab"));
                startActivity(browserIntent);
            }

        });

        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/search?rlz=1C1CHBF_en-GBAU821AU821&sxsrf=ALeKk01GRZJnPIQ4c9thhxRsI2y4isuEdQ%3A1591000783484&ei=z77UXoH-HJm_3LUPn-Og8Aw&q=nearest+pet+dentist+to+me&oq=nearest+pet+dentist+to+me&gs_lcp=CgZwc3ktYWIQAzIICCEQFhAdEB4yCAghEBYQHRAeMggIIRAWEB0QHjoECAAQRzoECCMQJzoFCAAQkQI6AggAOgQIABAKOgUIIRCgAToGCAAQFhAeUP3yA1jthQRgzYYEaABwAngAgAH3AYgBhRqSAQYwLjE2LjKYAQCgAQGqAQdnd3Mtd2l6&sclient=psy-ab&ved=0ahUKEwjBoaXkm-DpAhWZH7cAHZ8xCM4Q4dUDCAw&uact=5"));
                startActivity(browserIntent);
            }
        });

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goingBackIntent = new Intent();
                setResult(RESULT_OK,goingBackIntent);
                finish();
            }
        });












    }
}
