package com.example.mypetappassignment.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.mypetappassignment.R;

public class LoginActivity extends AppCompatActivity {
Button backButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        backButton = findViewById(R.id.backButtonLogin);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goingBackFrmLogin = new Intent();
                setResult(RESULT_OK,goingBackFrmLogin);
                finish();
            }
        });

    }
}
