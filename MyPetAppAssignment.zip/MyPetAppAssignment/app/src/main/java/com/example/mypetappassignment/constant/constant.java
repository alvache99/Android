package com.example.mypetappassignment.constant;

public class constant {
    public static Integer ADD_PET_ACTIVITY_CODE = 1;

}
