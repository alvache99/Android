package com.example.mypetappassignment.services;

import android.content.Context;
import android.util.Log;

import com.example.mypetappassignment.database.PetDbHelper;
import com.example.mypetappassignment.entities.Pet;

import java.util.List;

public class DataService {

    private PetDbHelper sqlite;

    public void connect(){

    }

    public void disconnect(){

    }

    public void init(Context context){
        sqlite = sqlite.getInstance(context);
    }

    public Long add(Pet pet){
        //
         sqlite.insert(pet.getName(), pet.getUsername(), pet.getType(),pet.getBreed(),pet.getAge(),pet.getImage());

        return 1L;
    }

    public boolean delete(Pet pet){
        return sqlite.delete(pet.getID());
    }

    public boolean update(Pet pet){


        return sqlite.update(pet.getID(), pet.getName(), pet.getUsername(), pet.getType(),pet.getBreed(),pet.getAge(),pet.getImage());
    }

    public List<Pet> getPets(){
        List<Pet> pets = sqlite.getPets();

        return pets;
    }
}
