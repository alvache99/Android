package com.example.mypetappassignment.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.mypetappassignment.R;

public class DetailViewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_view);
    }
}
