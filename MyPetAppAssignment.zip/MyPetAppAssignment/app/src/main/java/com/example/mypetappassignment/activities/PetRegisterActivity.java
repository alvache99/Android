package com.example.mypetappassignment.activities;

import android.content.Intent;
import android.os.Bundle;

import com.example.mypetappassignment.R;
import com.example.mypetappassignment.entities.Pet;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class PetRegisterActivity extends AppCompatActivity {
private EditText nameText;
    private EditText ageText;
    private EditText breedText;
    private EditText typeText;
    private Button cancelBtn;
    private Button confirmBtn;
    private Pet pet;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pet_register);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        nameText = findViewById(R.id.petNameReg);
        ageText = findViewById(R.id.petAgeReg);
        breedText = findViewById(R.id.petBreedReg);
        typeText = findViewById(R.id.petTypeReg);
        cancelBtn = findViewById(R.id.backFromReg);
        confirmBtn = findViewById(R.id.confirmReg);

        confirmBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                add(v);
            }
        });

        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                back(v);
            }
        });



    }
    private void add(View v) {

        String name = nameText.getText().toString();
        if(name.trim().isEmpty()){
            Snackbar.make(v, "Name is required", Snackbar.LENGTH_SHORT).show();
            nameText.getText().clear();
            return;
        }
        String ageRaw =  ageText.getText().toString();
        Long age = Long.parseLong(ageRaw);
        String breed = breedText.getText().toString();
        String type = typeText.getText().toString();
        String image = "";
        if(type.equalsIgnoreCase("dog")){
            image = "dog.jpg";
        }else if(type.equalsIgnoreCase("cat")){
            image="cat.jpg";
        }


       pet = new Pet();
        pet.setName(name);
        pet.setBreed(breed);
        pet.setImage(image);
        pet.setType(type);
        pet.setUsername("Default");
        pet.setAge(age);


        Intent goingBack = new Intent();
        goingBack.putExtra(Pet.PET_KEY, pet);
        setResult(RESULT_OK, goingBack);
        finish();
    }

    private void back(View V){

        setResult(RESULT_CANCELED);
        finish();
    }
}
