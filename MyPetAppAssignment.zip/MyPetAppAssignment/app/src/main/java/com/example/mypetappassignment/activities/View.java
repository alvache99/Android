package com.example.mypetappassignment.activities;

import android.content.Intent;
import android.os.Bundle;

import com.example.mypetappassignment.R;
import com.example.mypetappassignment.entities.Pet;
import com.example.mypetappassignment.recyclerview.PetRecyclerViewAdapter;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class View extends AppCompatActivity {
ArrayList<Pet> pets;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);



        RecyclerView petRecyclerView = findViewById(R.id.petRecyclerViewID);

        PetlistActivity tryinstant = new PetlistActivity();
        LinearLayoutManager LLM = new LinearLayoutManager(this);
        LLM.setOrientation(LinearLayoutManager.VERTICAL);
       // GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 2, GridLayoutManager.VERTICAL, false);
        petRecyclerView.setLayoutManager(LLM);


       // tryinstant.petDataService.init(this);
        //pets=tryinstant.petDataService.getPets();
        Intent dataIntent = getIntent();
        pets  = (ArrayList<Pet>) dataIntent
                .getSerializableExtra(Pet.PET_KEY);


        PetRecyclerViewAdapter adapter = new PetRecyclerViewAdapter(pets,this);
        petRecyclerView.setAdapter(adapter);




    }

}
